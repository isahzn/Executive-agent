# Tax Desk — Design System (MASTER)

Scope: visual design only. No routes, flows, copy logic, or data behavior change.
Every component here keeps its existing props/behavior — only the classNames change.

## Subject & audience

A deterministic tax calculation tool for Sri Lanka (individual, business, VAT,
withholding). Audience: people who need a correct number they can defend to
the IRD, not a marketing surface. The core artifact of this product is a
**figure** — LKR amounts, rates, bands. Precision and auditability are the
brand, not friendliness.

## Color

| Token | Hex | Role |
|---|---|---|
| `canvas` | `#f6f5f2` | page background — warm paper, not cold grey |
| `surface` | `#ffffff` | card/panel |
| `surface-dim` | `#faf9f6` | sidebar, subtle recessed areas |
| `ink` | `#181c1a` | primary text |
| `ink-soft` | `#565f5b` | secondary text |
| `ink-faint` | `#8d948f` | tertiary/muted |
| `line` | `#e4e1da` | borders, dividers (warm, not blue-grey) |
| `line-strong` | `#cfccc2` | stronger borders, hover states |
| `navy` | `#12233a` | brand / primary emphasis (deepened from current) |
| `navy-soft` | `#1c3252` | hover/active navy |
| `accent` | `#0a6b4c` | positive / money-in / confirm — kept close to existing green, slightly deepened |
| `accent-soft` | `#e8f1ec` | positive tint |
| `warn` | `#8a5200` | warning |
| `warn-soft` | `#f7efdf` | warning tint |
| `danger` | `#9e281f` | negative / error |
| `danger-soft` | `#f8eae8` | negative tint |
| `gold` | `#9c7a2e` | single reserved accent — "verified ruleset" / ledger-stamp moments only |
| `gold-soft` | `#f3ecd9` | gold tint |

Change from current palette: warm off-white canvas instead of cool grey
(`#f7f8f8` → `#f6f5f2`), deepened navy for more authority, and one new
reserved accent (`gold`) used *only* for the verified-ruleset indicator — a
ledger/stamp signal, not a decorative color. Everything else stays
semantic-only, as the current system already gets right.

## Type

Two families:
- **Display / numbers**: `Source Serif 4` (or fallback `Georgia`) at
  large sizes for money figures and page titles only — a serif gives
  tax figures the weight of a printed statement, distinct from every
  "AI dashboard" sans-only look.
- **UI / body**: keep `Geist Sans` for labels, nav, body text, buttons —
  it's already clean and functions well at small sizes.

Rule: serif appears in exactly two places — H1 page titles, and the large
`Stat` value figures. Nowhere else. This is the one deliberate typographic
choice; everything else stays plain sans so the serif keeps its weight.

Scale (Tailwind-mapped):
- Page title (`PageHeader` h1): serif, `text-3xl` (up from `text-2xl`), tight tracking
- Stat value: serif, `text-3xl` (up from `text-2xl`)
- Card title: sans, `text-sm font-semibold` (unchanged)
- Body: sans, `text-sm` (unchanged)
- No all-caps labels except the existing nav section headers (already
  functionally a sequence-independent grouping label, and small/muted
  enough not to read as template chrome) — do not add new ones.

## Layout

Unchanged: sidebar app shell (desktop), top tab bar (mobile), max-w-6xl
content column. No structural change — same grid, same breakpoints, same
component tree. Only surface treatment changes:

- Cards: reduce border-radius from `rounded-lg` to `rounded-md` (currently
  slightly too soft for a financial-document feel) and swap the current
  flat 1px shadow for a slightly more deliberate two-layer shadow that
  reads as a raised paper card, not a SaaS tile.
- Sidebar: switch from flat `surface-dim` fill to `canvas` with a single
  right hairline — makes it feel like a fixed ledger margin rather than a
  generic app rail.

## Components

- **Card**: `rounded-md`, border `line`, new shadow
  `0 1px 2px rgba(24,28,26,0.05), 0 1px 8px rgba(24,28,26,0.03)`. Header
  keeps the bottom hairline; no other change.
- **Button primary**: `bg-navy` → deepened navy, `rounded-md` (was
  already md — keep). No shape change, color only.
- **Badge "verified" tone**: introduce `gold` tone specifically for
  `RulesetBadge` when verified — replaces the current `accent` (green)
  use there, since green is reserved for money-positive elsewhere. Every
  other badge tone (`positive`/`negative`/`warn`/`info`) unchanged.
- **Stat**: value goes serif + slightly larger; label/sub unchanged sans.
- **Brand mark**: replace the flat "TD" square with a simple monogram
  in a thin-bordered square (still text-based, still no imagery/logo
  invented) — navy background, serif "TD", subtle inset border for a
  stamped-seal feel appropriate to an audited-figures product.
- **Field/Select**: unchanged shape; focus ring color updated to match
  deepened `navy-soft`.

## What does NOT change

- Any route, page composition, or component prop/behavior
- Copy/content, labels, microcopy
- Data flow, calculation logic, history/upload functionality
- Grid structure, breakpoints, nav items, mobile tab bar behavior
- Reduced-motion handling (already correct — no new animation added)

## Principle

One typographic move (serif for figures), one new reserved accent (gold,
verified-only), warmer neutrals throughout. Everything else stays as
restrained as the current system — the goal is *more considered*, not
*more decorated*.
