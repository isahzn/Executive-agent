import Link from "next/link";
import type { Metadata } from "next";
import { PageHeader } from "@/components/page-header";
import { Card, CardHeader, CardBody } from "@/components/ui/card";
import { Stat } from "@/components/ui/stat";
import { Badge } from "@/components/ui/badge";
import { getActiveRuleSet, getRuleSet } from "@/lib/tax";
import { formatMoney, formatRate } from "@/lib/tax/money";
import { getPersistence } from "@/lib/database";
import type { SavedCalculation, CalculationType } from "@/lib/database";

export const metadata: Metadata = {
  title: "Dashboard",
};

const TYPE_LABEL: Record<CalculationType, string> = {
  INDIVIDUAL_INCOME: "Individual Income Tax",
  BUSINESS: "Business Tax",
  VAT: "VAT",
  WITHHOLDING: "Withholding Tax",
};

function formatDate(iso: string): string {
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? iso : d.toLocaleString("en-US");
}

/** Extract the key figure from a saved calculation for dashboard display. */
function extractKeyFigure(calc: SavedCalculation): {
  label: string;
  value: string;
  type: CalculationType;
} {
  const result = calc.result as Record<string, unknown>;
  switch (calc.type) {
    case "INDIVIDUAL_INCOME": {
      const totalTax = (result.totalTax as number) ?? 0;
      return {
        label: TYPE_LABEL[calc.type],
        value: formatMoney(totalTax, "LKR"),
        type: calc.type,
      };
    }
    case "VAT": {
      const netVat = (result.netVat as number) ?? 0;
      const position = (result.position as string) ?? "NIL";
      return {
        label: TYPE_LABEL[calc.type],
        value:
          position === "PAYABLE"
            ? `Payable ${formatMoney(netVat, "LKR")}`
            : position === "REFUNDABLE"
              ? `Refundable ${formatMoney(Math.abs(netVat), "LKR")}`
              : "Nil",
        type: calc.type,
      };
    }
    case "WITHHOLDING": {
      const withholding = (result.withholding as number) ?? 0;
      return {
        label: TYPE_LABEL[calc.type],
        value: formatMoney(withholding, "LKR"),
        type: calc.type,
      };
    }
    case "BUSINESS": {
      const totalTax = (result.totalTax as number) ?? null;
      const taxStatus = (result.taxStatus as string) ?? "NOT_IMPLEMENTED";
      return {
        label: TYPE_LABEL[calc.type],
        value:
          totalTax != null
            ? formatMoney(totalTax, "LKR")
            : taxStatus === "NEEDS_ALLOCATION"
              ? "Needs allocation"
              : "Awaiting rules",
        type: calc.type,
      };
    }
    default:
      return { label: "Unknown", value: "—", type: calc.type };
  }
}

export default async function DashboardPage() {
  const ruleset = getActiveRuleSet(
    { jurisdiction: "LK", taxType: "INDIVIDUAL_INCOME" },
    "2025-07-01"
  );

  const relief = ruleset?.rules.find((r) => r.category === "PERSONAL_RELIEF");
  const topRate = ruleset?.rules
    .filter((r) => r.category === "PROGRESSIVE_BAND")
    .sort((a, b) => (b as { rate: number }).rate - (a as { rate: number }).rate)[0];

  // Fetch latest calculations from history for live dashboard data
  const calculations = await getPersistence().list();
  const latest = calculations.length > 0 ? calculations[0] : null;
  const latestKeyFigure = latest ? extractKeyFigure(latest) : null;

  // Count by type
  const counts: Record<CalculationType, number> = {
    INDIVIDUAL_INCOME: 0,
    BUSINESS: 0,
    VAT: 0,
    WITHHOLDING: 0,
  };
  for (const c of calculations) {
    counts[c.type]++;
  }

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Dashboard"
        subtitle="Your tax position at a glance. All figures derive from the deterministic rule engine — no AI computes tax."
      />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {latest ? (
          <>
            <Stat
              label="Latest calculation"
              value={latestKeyFigure?.value ?? "—"}
              tone="positive"
              sub={`${TYPE_LABEL[latest.type]} · ${latest.taxYear}`}
            />
            <Stat
              label="Total calculations"
              value={String(calculations.length)}
              tone="neutral"
              sub={`Last run ${formatDate(latest.createdAt)}`}
            />
          </>
        ) : (
          <>
            <Stat
              label="Tax payable"
              value="—"
              tone="neutral"
              sub="No calculations yet"
            />
            <Stat
              label="Calculations run"
              value="0"
              tone="neutral"
              sub="Run your first calculation"
            />
          </>
        )}
        <Stat
          label="VAT position"
          value={counts.VAT > 0 ? `${counts.VAT} calculated` : "—"}
          tone={counts.VAT > 0 ? "positive" : "neutral"}
          sub={counts.VAT > 0 ? "See VAT calculator" : "Use the VAT calculator"}
        />
        <Stat
          label="Rules loaded"
          value="4"
          tone="neutral"
          sub="Sri Lanka 2025/2026"
        />
      </div>

      {/* Recent calculations */}
      {calculations.length > 0 ? (
        <Card>
          <CardHeader
            title="Recent calculations"
            subtitle={`${calculations.length} total · most recent first`}
          />
          <CardBody className="p-0">
            <ul className="flex flex-col">
              {calculations.slice(0, 5).map((calc) => {
                const kf = extractKeyFigure(calc);
                return (
                  <li key={calc.id}>
                    <Link
                      href={`/history/${calc.id}`}
                      className="flex items-center justify-between gap-3 border-b border-line px-5 py-3 text-sm transition-colors hover:bg-surface-dim last:border-0"
                    >
                      <span className="flex items-center gap-2.5">
                        <Badge tone="info">{TYPE_LABEL[calc.type]}</Badge>
                        <span className="text-ink">Year {calc.taxYear}</span>
                      </span>
                      <span className="flex items-center gap-4">
                        <span className="tabular font-medium text-ink">{kf.value}</span>
                        <span className="text-xs text-ink-faint tabular">{formatDate(calc.createdAt)}</span>
                      </span>
                    </Link>
                  </li>
                );
              })}
            </ul>
          </CardBody>
        </Card>
      ) : null}

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader
            title="Quick actions"
            subtitle="Start with a calculation or bring your own data."
          />
          <CardBody className="flex flex-col gap-3">
            <QuickAction
              href="/tax/individual"
              title="Calculate individual income tax"
              description="Enter income and deductions to get an audited 2025/2026 result."
            />
            <QuickAction
              href="/tax/individual#import"
              title="Import financial data"
              description="Upload a CSV or Excel file and map columns into a calculation."
            />
            <QuickAction
              href="/tax/vat"
              title="Calculate VAT"
              description="Calculate output/input VAT or check registration status."
            />
            <QuickAction
              href="/tax/business"
              title="Calculate business tax"
              description="Compute taxable profit across income categories with attributable expenses."
            />
            <QuickAction
              href="/tax/withholding"
              title="Calculate withholding tax"
              description="Check WHT/AIT on payments with verified rates and thresholds."
            />
            <QuickAction
              href="/history"
              title="Browse calculation history"
              description="Reopen a saved calculation and see exactly how it was derived."
            />
          </CardBody>
        </Card>

        <Card>
          <CardHeader
            title="Active ruleset"
            subtitle="Source of truth for calculations"
            action={
              <Badge tone={ruleset?.verified ? "gold" : "warn"}>
                {ruleset?.verified ? "Verified" : "Unverified"}
              </Badge>
            }
          />
          <CardBody className="flex flex-col gap-3">
            <div>
              <p className="text-xs uppercase tracking-wide text-ink-soft">Jurisdiction · Year</p>
              <p className="mt-0.5 text-sm font-medium text-ink">
                Sri Lanka · {ruleset?.taxYear ?? "—"}
              </p>
            </div>
            <div>
              <p className="text-xs uppercase tracking-wide text-ink-soft">Personal relief</p>
              <p className="mt-0.5 text-sm font-medium text-ink tabular">
                {relief?.category === "PERSONAL_RELIEF"
                  ? formatMoney(relief.amount, ruleset?.currency)
                  : "—"}
              </p>
            </div>
            <div>
              <p className="text-xs uppercase tracking-wide text-ink-soft">Top marginal rate</p>
              <p className="mt-0.5 text-sm font-medium text-ink tabular">
                {topRate ? formatRate((topRate as { rate: number }).rate) : "—"}
              </p>
            </div>
            <p className="border-t border-line pt-3 text-xs text-ink-faint">
              New tax years and jurisdictions are added as versioned rulesets — the engine logic does not change.
            </p>
          </CardBody>
        </Card>
      </div>
    </div>
  );
}

function QuickAction({
  href,
  title,
  description,
  disabled,
}: {
  href: string;
  title: string;
  description: string;
  disabled?: boolean;
}) {
  const inner = (
    <div className="flex items-start justify-between gap-4">
      <div>
        <p className="text-sm font-medium text-ink">{title}</p>
        <p className="mt-0.5 text-xs text-ink-soft">{description}</p>
      </div>
      <span className="text-ink-faint" aria-hidden>
        →
      </span>
    </div>
  );
  return (
    <Link
      href={href}
      className={
        "rounded-md border border-line bg-surface px-4 py-3 transition-colors " +
        (disabled
          ? "pointer-events-none opacity-60"
          : "hover:border-line-strong hover:bg-surface-dim")
      }
      aria-disabled={disabled || undefined}
    >
      {inner}
    </Link>
  );
}
